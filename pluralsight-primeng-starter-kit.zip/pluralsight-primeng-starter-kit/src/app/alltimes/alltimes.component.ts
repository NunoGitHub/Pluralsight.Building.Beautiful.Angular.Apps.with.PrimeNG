import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'at-alltimes',
  templateUrl: './alltimes.component.html',
  styleUrls: ['./alltimes.component.css']
})
export class AlltimesComponent implements OnInit {

  constructor() {
  }


  ngOnInit() {

  }

}
